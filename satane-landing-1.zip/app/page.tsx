
import Image from "next/image";
import BuySTNButton from "@/components/BuySTNButton";
import ConnectWallet from "@/components/ConnectWallet";

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-black text-red-600 p-8">
      <Image src="/logo.gif" alt="SatanéCoin Logo" width={120} height={120} />
      <h1 className="text-4xl font-bold mt-4">Bienvenue dans l’enfer crypto</h1>
      <p className="mt-2 text-lg">SatanéCoin ($STN)</p>
      <div className="mt-4 space-y-2">
        <p>Prix du SOL : ~138.00 €</p>
        <p>Holders STN : 137</p>
      </div>
      <div className="mt-6 flex gap-4">
        <ConnectWallet />
        <BuySTNButton />
      </div>
    </main>
  );
}
