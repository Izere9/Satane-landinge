
"use client";

export default function ConnectWallet() {
  const handleClick = async () => {
    if ((window as any).solana?.isPhantom) {
      try {
        const resp = await (window as any).solana.connect();
        alert('Connecté: ' + resp.publicKey.toString());
      } catch (err) {
        alert('Connexion refusée.');
      }
    } else {
      alert('💡 Ouvre ce site dans l’app Phantom.');
    }
  };

  return (
    <button
      onClick={handleClick}
      className="bg-red-600 text-white px-4 py-2 rounded-lg shadow"
    >
      Connecter Phantom
    </button>
  );
}
